"""Codex runtime lifecycle actions."""
