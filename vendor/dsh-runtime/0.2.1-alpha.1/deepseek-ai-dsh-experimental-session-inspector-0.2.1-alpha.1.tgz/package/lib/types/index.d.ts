/** Host discovery entry for the Session Inspector browser plugin. */
/** Mount the inert Host half; Session inspection belongs to the Client. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map