/** Browser plugin contributing the Session Inspector Log sidebar tab. */
import type { Context } from '@deepseek-ai/cordis';
/** Services required to register the localized Session-bound sidebar tab. */
export declare const inject: string[];
/**
 * Register the Inspector tab for this plugin's lifetime.
 * @param ctx - Client plugin context owning the dictionaries and registrations.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map