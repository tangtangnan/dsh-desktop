/**
 * Event-sourced session service: append-only session log, in-memory store, and
 * the derived LLM message history. Persistence is a plugin concern (subscribe
 * to `session/event`, drain on `session/flush`).
 *
 * @module @deepseek-ai/dsh-session
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Scoped } from '@deepseek-ai/dsh-scope';
import type { Message } from '@deepseek-ai/dsh-llm';
import { SessionLogOffset, SessionSeq } from './types.ts';
import type { TypertLookup } from '@deepseek-ai/dsh-typert-protocol';
import type { CreateSessionOptions, EpochHeader, PrepareSessionOptions, RequestContext, SessionEvent, SessionEventMap, SessionEventType, SessionHeader, SessionId, SessionSeedEventState, SurfaceIntent, SurfaceEventType } from './types.ts';
import type { SessionSurface, SessionMessageProjection } from './surface.ts';
import type { ToolHistory } from '@deepseek-ai/dsh-llm';
export { buildForkSeed } from './fork.ts';
export * from './types.ts';
export { SessionPreparation } from './preparation.ts';
export type { SessionPreparationOptions } from './preparation.ts';
export type { AssistantMessage, DeveloperMessage, SystemMessage, ToolResultMessage, UserMessage } from '@deepseek-ai/dsh-llm';
export { interruptedTurnClosers, ToolCallRecovery, TOOL_NOT_STARTED, TOOL_OUTCOME_UNKNOWN } from './repair.ts';
export type { SessionSurface, SurfaceFoldReplacement, SurfaceFoldResult, SessionMessageProjection, SessionMessageProjectionContext } from './surface.ts';
export { deriveEventMessage, foldSurface, isAppendSurfaceEvent, isReplacementSurfaceEvent, isSurfaceEvent, isSurfaceEligibleType } from './surface.ts';
export { canonicalHeader, foldRequestHeader, headerEquals } from './request-header.ts';
export { KNOWN_SESSION_EVENT_TYPES } from './known-event-types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        sessions: SessionStore;
    }
    interface Events {
        /**
         * Creation announcement during session publication. A synchronous throw vetoes and rolls
         * back with a paired disposal; detach requested during dispatch is deferred.
         * A returned-promise rejection is logged but cannot retroactively veto this
         * synchronous boundary.
         * Scope-filtered dispatch (`@deepseek-ai/dsh-scope`): agent-scoped listeners
         * receive only sessions entered through that agent's context.
         * @param session - the session just entered and announced.
         * @mode emit
         */
        'session/created'(this: Scoped<Session>, session: Session): void;
        /**
         * Emitted once when an announced session leaves the store, including
         * publication rollback, but never for an entry whose creation announcement
         * did not begin. Listener failures are logged and contained.
         * Scope-filtered dispatch (`@deepseek-ai/dsh-scope`) reuses the owner scope.
         * @param session - the session that is no longer live in the store.
         * @mode emit
         */
        'session/disposed'(this: Scoped<Session>, session: Session): void;
        /**
         * Post-commit, fire-and-forget append feed. The listener snapshot resolves
         * before the log push, but callbacks run after it; observer failures are
         * logged and contained without making the committed append fail.
         * Scope-filtered dispatch (`@deepseek-ai/dsh-scope`): agent-scoped listeners
         * receive only events from sessions entered through that agent's context.
         * @param session - the session whose log grew.
         * @param event - the appended event, exactly as recorded.
         * @mode emit
         */
        'session/event'(this: Scoped<Session>, session: Session, event: SessionEvent): void;
        /**
         * Awaited parallel durability checkpoint: every listener runs and the
         * caller awaits all of them, with no waterfall veto. Scope-filtered dispatch
         * (`@deepseek-ai/dsh-scope`) reuses the session's owner scope.
         * @param session - the session whose buffered events must reach durable storage.
         * @mode parallel
         */
        'session/flush'(this: Scoped<Session>, session: Session): Promise<void> | void;
    }
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertLookupMap {
        session: TypertLookup<Session, SessionId>;
    }
}
/**
 * Validate an exclusively owned event and deeply freeze its identified message
 * without copying the event. The caller transfers an object graph that no
 * producer retains and that shares no mutable children with another event.
 * Use {@link snapshotSessionEvent} when exclusive ownership is not guaranteed.
 * @param event - exclusively owned event imported across a trusted boundary.
 * @returns the same event object with a validated, deeply frozen message.
 * @throws when event-local surface metadata, request-header fields, or message invariants are invalid; history relations are not checked.
 */
export declare function adoptSessionEvent<T extends SessionEvent>(event: T): T;
/**
 * Detach one event while preserving deep immutability for its identified message.
 * @param event - event imported across a query or persistence boundary.
 * @returns a detached event snapshot with a validated, deeply frozen message.
 */
export declare function snapshotSessionEvent<T extends SessionEvent>(event: T): T;
/**
 * An event-sourced session: an append-only log of {@link SessionEvent}s.
 *
 * Plain class (not a Service) — create live instances via
 * `ctx.sessions.create()` and detached instances via {@link create}.
 * Seeding with an existing event log replays/forks a session.
 * @typert object
 */
export declare class Session {
    private log;
    /** Single incremental owner of surface acceptance and projection state. */
    private readonly surfaceManager;
    /** The ordered surface over this session's event log. */
    get surface(): SessionSurface;
    /**
     * Detached, deep-frozen creation metadata (format version, cwd, lineage,
     * and whether fork history exists). Supplied by the store via `ctx.sessions.create()`. When a
     * `Session` is created without a store-owned header, a minimal header is
     * synthesized (stamped with the current {@link SESSION_FORMAT_VERSION}) so
     * `session.header` is always present. Kept out of the event log — it is a
     * storage concern, not replayable conversation state.
     */
    readonly header: SessionHeader;
    /** Number of leading events inherited from this Session's fork parent. */
    readonly inheritedEventCount: SessionLogOffset;
    /** The session identity, derived from its durable header's single copy. */
    get id(): SessionId;
    /**
     * The constructor seed length (0 without one), before any marker appended
     * during construction. Seed events never publish on `session/event`. A
     * marker appended before the store attaches occupies this seq without
     * publishing either; otherwise this seq is available for the next append.
     *
     * This in-process offset is not persisted. A fork seed can already contain
     * the child's inherited marker and synthetic closers, so its child-owned
     * history starts at {@link inheritedEventCount}, before this offset. A
     * resumed Session's seed contains its full stored log, while its inherited
     * count keeps the durable fork cut. Consumers needing complete canonical
     * history start at seq 0.
     */
    readonly firstLiveSeq: SessionLogOffset;
    /**
     * First event produced for this object lifecycle. A new fork includes its
     * child-owned seed marker and closers; a restored Session starts after its
     * complete stored prefix. This in-process capture offset is not persisted.
     */
    readonly firstLifecycleSeq: SessionLogOffset;
    /**
     * Create a detached session by validating and snapshotting borrowed seed
     * events and storage metadata.
     * @param id - session identity.
     * @param seed - optional borrowed replay or fork events.
     * @param header - optional borrowed storage metadata.
     * @param inheritedEventCount - exact fork-inherited prefix length for a seeded header.
     * @param projections - pure interpreters for plugin-owned message changes.
     * @returns a detached session.
     * @throws when a seed event requires a missing message interpreter or fails validation.
     */
    static create(id: SessionId, seed?: readonly SessionEvent[], header?: SessionHeader, inheritedEventCount?: SessionLogOffset, projections?: readonly SessionMessageProjection[]): Session;
    /**
     * Restore a detached session by adopting an independently owned or deeply frozen seed.
     * Runtime-required event fields, event envelopes, sequence continuity, surface
     * transitions, and header fields are validated without copying or freezing events.
     * Embedded Assistant streams remain opaque until a stream consumer or storage
     * verifier reads them.
     * @param id - restored session identity.
     * @param seed - independently owned or deeply frozen events.
     * @param header - independently owned storage metadata.
     * @param inheritedEventCount - exact fork-inherited prefix length decoded from storage.
     * @param eventState - aliasing state carried from the operation that produced the seed.
     * @param projections - pure interpreters for plugin-owned message changes.
     * @returns a restored detached session.
     * @throws when a seed event requires a missing message interpreter or fails validation.
     */
    static fromRestore(id: SessionId, seed: readonly SessionEvent[], header: SessionHeader, inheritedEventCount: SessionLogOffset, eventState: SessionSeedEventState, projections?: readonly SessionMessageProjection[]): Session;
    private constructor();
    /** Cached immutable full snapshot of the private append-only log. */
    private eventsSnapshot;
    /**
     * Return the immutable event stored at one exact sequence number.
     * @deprecated Existing logic may remain unmigrated for now, but new calls are prohibited.
     * See the [Agent Note](../../../../.agents/notes/implemented/architecture/2026-09-09-deprecate-synchronous-session-event-reads.md).
     * @param seq - event sequence number.
     * @returns the accepted event, or undefined when the log does not contain it.
     */
    eventAt(seq: SessionSeq): SessionEvent | undefined;
    /**
     * Materialize an immutable snapshot of a half-open event sequence range.
     * A full current snapshot is reused until the next append; every previously
     * returned snapshot remains stable after later appends.
     * @deprecated Existing logic may remain unmigrated for now, but new calls are prohibited.
     * See the [Agent Note](../../../../.agents/notes/implemented/architecture/2026-09-09-deprecate-synchronous-session-event-reads.md).
     * @param fromSeq - non-negative inclusive sequence number; defaults to the log start.
     * @param toSeqExclusive - non-negative exclusive sequence number; defaults to the current end.
     * @returns a frozen array of the selected deeply frozen events.
     */
    snapshotEvents(fromSeq?: SessionLogOffset, toSeqExclusive?: SessionLogOffset): readonly SessionEvent[];
    /**
     * Return this Session's events after its fork-inherited prefix.
     * @deprecated Existing logic may remain unmigrated for now, but new calls are prohibited.
     * See the [Agent Note](../../../../.agents/notes/implemented/architecture/2026-09-09-deprecate-synchronous-session-event-reads.md).
     * @returns a fresh array containing child-owned events in log order.
     */
    ownEvents(): readonly SessionEvent[];
    /**
     * Whether one existing event position is outside the fork-inherited prefix.
     * @param seq - event position in this Session.
     * @returns true when the event belongs to this Session rather than its parent.
     */
    isOwnSeq(seq: SessionSeq): boolean;
    /** The next event's sequence number — always the log length (the `seq = log.length` contiguity contract). */
    get seq(): SessionLogOffset;
    /**
     * Append one typed event to the log and synchronously notify observers via
     * the store-owned, module-private publication hooks. The hot path never blocks
     * on I/O — persistence plugins buffer asynchronously. Once the event enters
     * the log, the append is committed: observer failures are logged and
     * contained per listener, so they do not change the return value or prevent
     * later listeners from observing the same accepted event.
     *
     * @param type - The event type (key of {@link SessionEventMap}).
     * @param data - The event payload; must be JSON-serializable.
     * @param opts - Surface metadata: `surfaceOp` controls how the event enters
     *   the ordered surface; `sourceEventSeqs` lists the seq numbers of earlier
     *   events this one derives from. REQUIRED for
     *   {@link SurfaceEventType} events (every message-producing event must
     *   declare how it joins the surface, the sole source of derived model
     *   history) and
     *   rejected by the compiler for non-surface types like `turn/start` or
     *   `assistant/attempt`. Assistant messages embed their exact provider
     *   stream and cannot cite top-level source events.
     * @returns the logged event — its assigned `seq`/`time` plus the SNAPSHOT of
     *   `data` that entered the log, so reading `event.data` back sees the logged
     *   value, never the caller's still-mutable input.
     * @throws if `data` or surface metadata is not losslessly JSON-serializable
     *   (BigInt, function, symbol, undefined, negative zero, non-finite number,
     *   circular reference, sparse array, or an exotic object such as
     *   Map/Set/Date/class instance), or when the candidate violates the
     *   request-header empty-field or tool-error consistency rules, or the
     *   canonical surface contract (marker shape and eligibility, unique
     *   earlier source-event references, positional replacement validity, and complete
     *   shadowed-node coverage). One iterative pass reads, validates, and
     *   copies each nested value once, so a stateful getter cannot supply one value
     *   to validation and another to storage. The event log is the durable source
     *   of truth, so a bad event fails at the append site rather than later during
     *   a backend flush. A synchronous internal dispatch validation failure or an
     *   append reentered while this acceptance/publication boundary is open also
     *   rejects before the log changes.
     */
    append<T extends SessionEventType>(type: T, data: SessionEventMap[T], ...opts: T extends SurfaceEventType ? [opts: SurfaceIntent<T>] : []): SessionEvent<T>;
    /** Cached fold of the request-header events — see {@link requestHeader}. */
    private headerFold;
    /** Log position (events consumed) the header fold has reached. */
    private headerFoldSeq;
    /**
     * The {@link EpochHeader} in force after the log's last header event — the
     * header the NEXT request will be compared against — or undefined before
     * the first `request/header` snapshot. The live, incrementally-maintained
     * form of `foldRequestHeader(session.snapshotEvents())`: each header event is folded
     * once, when first seen, so a per-step read costs O(new events).
     * @returns the folded header, or undefined when no header event exists yet.
     */
    requestHeader(): EpochHeader | undefined;
    /** Cached fold of `request/context` events. */
    private contextFold;
    private contextFoldSeq;
    /**
     * Return the latest resolved route metadata, or `undefined` before the first
     * `request/context` event. Each event is folded once.
     * @returns the latest immutable route metadata.
     */
    requestContext(): RequestContext | undefined;
    /** Cached historical tool definitions and updates for request projection. */
    private readonly toolHistoryProjection;
    /** Index of the next committed event not yet consumed by the tool-history fold. */
    private toolHistorySeq;
    /**
     * Fold unseen committed events into capability-independent tool history.
     * Initial access reconstructs inherited history; later reads consume only new events.
     * @returns an immutable snapshot for LLM request projection, including historical addition definitions.
     */
    toolHistory(): ToolHistory;
    /** The derived-message cache: frozen projections, extended per unseen node. */
    private derived;
    /** Surface position (nodes projected) the cache has reached. */
    private derivedNodes;
    /** {@link SurfaceManager.contentGeneration} the cache was built under. */
    private derivedGeneration;
    /**
     * Derive the LLM message history by walking the ordered sequences of
     * message-producing events maintained by `surfaceOp` markers. The
     * surface is the single source of derived history: every message-producing
     * append records its `surfaceOp`, so a raw event with no marker (a chunk, a
     * turn boundary) is correctly absent, and a compaction `replace` deletes the
     * shadowed nodes from the derivation. The projection rules are
     * {@link deriveEventMessage}, with logged message projections applied
     * without changing node membership or message identity.
     *
     * CACHED: pure tail growth costs O(new nodes); a replacement or message projection
     * ({@link SessionSurface.contentGeneration}) rebuilds. The returned array is
     * a fresh snapshot per call (later appends never grow an array a caller
     * already holds); the `Message` objects in it are SHARED and **deep-frozen**.
     * Unchanged content reuses frozen event data; projected blocks are frozen
     * derived copies. Consumers cannot mutate the log through either form.
     * @returns a fresh array of the shared, frozen derived history.
     */
    deriveMessages(): Message[];
    /**
     * Project one event with all committed message projections applied.
     * The original durable event remains unchanged.
     * @param event - the event to project.
     * @returns the derived message, or null when the event produces none.
     */
    deriveEventMessage(event: SessionEvent): Message | null;
}
/** A fork source: either the live session object or its live store id. */
export type SessionForkSource = Session | SessionId;
/**
 * Rejection codes for session forking: the fork source id is unknown to the
 * live store (`SESSION_NOT_FOUND`) or names a session object that is not the
 * store's live instance (`SESSION_NOT_LIVE`); the requested child id is
 * already taken (`SESSION_ALREADY_EXISTS`); or the boundary is not a contiguous
 * existing seq (`INVALID_BOUNDARY`).
 */
export type SessionForkErrorCode = 'SESSION_NOT_FOUND' | 'SESSION_NOT_LIVE' | 'SESSION_ALREADY_EXISTS' | 'INVALID_BOUNDARY';
/** Typed error for session fork rejections. */
export declare class SessionForkError extends Error {
    readonly code: SessionForkErrorCode;
    constructor(message: string, code: SessionForkErrorCode);
}
/**
 * In-memory session store (`ctx.sessions`).
 *
 * Persistence is intentionally not implemented here — the agent lifecycle
 * attaches a session-log writer to each published session's write handle;
 * a session published outside that lifecycle persists nothing.
 */
export declare class SessionStore extends Service {
    private store;
    private counter;
    private readonly projections;
    /** Borrowed definitions for detached replay; contributions live until their registering fibers unload. */
    get messageProjections(): readonly SessionMessageProjection[];
    /**
     * Register one event interpreter for live creation, restore, and fork.
     * Disposing the contribution makes sessions that used it refuse further derivation.
     * @param projection - pure definition owned by the event's plugin.
     * @returns the fiber-owned disposer.
     * @throws when another definition already owns this event type.
     */
    registerMessageProjection(projection: SessionMessageProjection): () => Promise<void>;
    constructor(ctx: Context);
    /**
     * Create a session owned by the calling fiber: disposing that fiber stops
     * event notification and removes the session from the store. `options.seed`
     * populates the session with a copy of those events (replay/fork);
     * `options.meta` attaches creation metadata (validated absolute `cwd`, seed
     * and parent lineage, and delegation depth) as the immutable
     * {@link SessionHeader} (the store fills `version`/`id`/`createdAt`).
     *
     * For an agent whose session must be torn down IN ORDER with its loop (so the
     * loop's final events are published before the store attachment ends), do NOT use this
     * — fold the session lifecycle into the agent's own effect via
     * {@link prepare} + {@link enter} + {@link announce} (see
     * `dsh-agent-loop`'s creation transaction).
     *
     * @param id - the session id; omitted, the store mints `session-<n>`.
     * @param options - seed events and/or creation metadata for the header.
     * @returns the live session, already entered and announced.
     * @throws if a session with `id` already exists, metadata is not a plain
     *   lossless-JSON record with valid scalar fields, or `meta.cwd` is a
     *   non-absolute path (storage backends key directories off it).
     */
    create(id?: SessionId, options?: CreateSessionOptions): Session;
    /**
     * Build a session WITHOUT entering it into the store — validate the id/cwd and
     * construct the {@link Session} (with its immutable {@link SessionHeader}).
     * Pairs with {@link enter} + {@link announce}: a caller that owns a composite
     * `ctx.effect` (the agent factory) folds the session lifecycle into that ONE
     * effect so a fiber unload tears the session + agent down as a single ORDERED
     * chain rather than as racing sibling effects — which would remove the publication hooks
     * before the driver's closing events commit, dropping them.
     *
     * @param id - the session id; omitted, the store mints `session-<n>`.
     * @param options - seed events and/or creation metadata for the header. With
     *   `eventState`, every seed event is either independently owned or any
     *   shared value is deeply frozen; {@link Session.fromRestore} validates and
     *   adopts those values without copying or freezing them.
     * @returns the constructed session, NOT yet in the store.
     * @throws if a session with `id` already exists, metadata is not a plain
     *   lossless-JSON record with valid scalar fields, or `meta.cwd` is a
     *   non-absolute path.
     */
    prepare(id?: SessionId, options?: PrepareSessionOptions): Session;
    /**
     * Enter a {@link prepare}d session into the store: install the module-private
     * append publication hooks and add it to the store. Returns the DETACH
     * disposer (hooks + store removal). Does NOT emit `session/created` —
     * the caller yields this disposer inside its effect and THEN calls
     * {@link announce}, so a throwing `session/created` listener rolls the attach
     * back instead of leaking it.
     *
     * Re-checks the id for a duplicate: `prepare` and `enter` are public
     * cross-package primitives and a caller may interleave arbitrary work (or
     * another create) between them, so a stale prepared session must NOT overwrite
     * a live store entry of the same id — its detach disposer would later delete
     * the REAL session. The {@link create} convenience and the agent factory call
     * the two back-to-back so they never trip this, but the public API cannot
     * assume that.
     *
     * @param session - a {@link prepare}d session not yet in the store.
     * @returns the detach disposer (publication hooks + store removal). When called from
     *   a synchronous `session/created` listener, removal and disposal wait until
     *   that creation dispatch unwinds.
     * @throws if a session with this id is already in the store.
     */
    enter(session: Session): () => void;
    /** Remove one exact entered session and emit its paired disposal when announced. */
    private detachEntered;
    /** Emit `session/created` exactly once for an {@link enter}ed session (with
     * the carrier {@link enter} captured). Separate from {@link enter} so the
     * caller can yield the detach disposer first (rollback safety — see
     * {@link enter}).
     * @param session - the entered session to announce to listeners.
     * @throws if the session is not live or its announcement already began,
     *   including a reentrant call from a creation listener. */
    announce(session: Session): void;
    /** Emit the paired teardown notification with per-listener containment. */
    private emitDisposed;
    /**
     * Dispatch the awaited `session/flush` durability checkpoint for `session`,
     * with the carrier captured at {@link enter}. THE flush entry point: the
     * store owns the carrier, so callers (the checkpoint policy's per-request
     * barrier, goal-round-driver's idle checkpoint, teardown drains, and consumers
     * that flush themselves before reading storage) must come through here
     * rather than dispatch a raw `ctx.parallel('session/flush', …)` — one owner
     * and one spelling.
     * @param session - the session whose buffered events must reach durable storage.
     * @returns whether at least one durability listener participated, after every
     *   listener has settled successfully.
     * @throws the first registered listener failure after every listener settles.
     */
    flush(session: Session): Promise<boolean>;
    /** Return the exact live entry; detached/prepared objects reject. */
    private liveEntryFor;
    /**
     * Look up a live session.
     * @param id - the session id to look up.
     * @returns the session, or undefined when no live session has that id.
     */
    get(id: SessionId): Session | undefined;
    /**
     * All live sessions, in creation order.
     * @returns a fresh array; mutating it does not affect the store.
     */
    list(): Session[];
    /**
     * Create a live child session from an exact prefix of a live source.
     * `boundary` is an inclusive source event seq; omitted means the source's
     * current last event. An open tail receives synthetic tool results and
     * step/turn closers with the forked cause. Closed steps and turns remain
     * unchanged, including any failed tool calls already missing results.
     * `inheritedEventCount` counts only copied source events, excluding these closers.
     *
     * @param source - Live source session object or id.
     * @param boundary - Inclusive source event seq to fork through; omitted means
     *   the source's current last event, and omitted on an empty source forks an
     *   empty child.
     * @param childSessionId - Optional child session id; omitted delegates to
     *   `SessionStore`'s id policy.
     * @returns The created live child session.
     */
    fork(source: SessionForkSource, boundary?: SessionSeq, childSessionId?: SessionId): Session;
    private _forkBoundary;
    private _resolveForkSource;
}
export { decodeSeqRanges, encodeSeqRanges } from './seq-ranges.ts';
export default SessionStore;
//# sourceMappingURL=index.d.ts.map