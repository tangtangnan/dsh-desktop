/** Fallback name for an untitled Client realm in the debugging protocol. */
export declare const untitledClientLabel = "Client";
//# sourceMappingURL=locales.d.ts.map