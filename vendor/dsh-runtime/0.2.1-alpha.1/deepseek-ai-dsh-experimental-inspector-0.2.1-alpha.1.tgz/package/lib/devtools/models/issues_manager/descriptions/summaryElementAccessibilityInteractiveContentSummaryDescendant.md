# Interactive element inside of a <summary> element

An interactive element was found within a `<summary>` element. These elements will not consistently be accessible to people navigating by keyboard or using assistive technology.
