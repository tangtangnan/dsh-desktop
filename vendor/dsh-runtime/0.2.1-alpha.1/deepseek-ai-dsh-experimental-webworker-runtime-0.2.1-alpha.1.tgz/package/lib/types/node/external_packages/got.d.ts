/** CommonJS interop marker for the worker loader's default import. */
export declare const __esModule = true;
/** Reject product telemetry HTTP requests without opening a connection. */
declare const got: {
    post: (...args: never[]) => never;
};
export default got;
//# sourceMappingURL=got.d.ts.map